﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Library
{
    public class Coord
    {
        public double lon { get; set; }
        public double lat { get; set; } 
    }
}
